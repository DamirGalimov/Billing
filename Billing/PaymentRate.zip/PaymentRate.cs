﻿using System;
using static Billing.DataChecking;

namespace Billing
{
    /// <summary>
    /// Работник получающий ЗП по ставке
    /// </summary>
    public class PaymentRate: IEmployee
    {
        /// <summary>
        /// Имя работника
        /// </summary>
        private string _name;
        /// <summary>
        /// Фамилия работника
        /// </summary>
        private string _surname;
        /// <summary>
        /// Возраст работника
        /// </summary>
        private int _age;
        /// <summary>
        /// Информация о том как начисляется ЗП
        /// </summary>
        private PaymentType _paymentType = PaymentType.PaymentRate;
        /// <summary>
        /// ставка НДЛФ в процентах
        /// </summary>
        private const int IncomeTax = 13;
        /// <summary>
        /// Размер оклада за месяц
        /// </summary>
        private double _salary;
        /// <summary>
        /// количество рабочих дней в месяце
        /// </summary>
        private month _currentMonth;
        /// <summary>
        /// Количество отработанных дней
        /// </summary>
        private int _daysWorked;
        /// <summary>
        /// Ставка работника
        /// </summary>
        private double _rate;

        /// <summary>
        /// Базовый конструктор
        /// </summary>
        public PaymentRate()
        { }

        /// <summary>
        /// Конструктор класса
        /// </summary>
        /// <param name="name">имя работника</param>
        /// <param name="surname">фамилия работника</param>
        /// <param name="age">возраст работника</param>
        /// <param name="salary">размер оклада на занимаемой должности</param>
        /// <param name="currentMonth">количество рабочих дней в месяце</param>
        /// <param name="daysWorked">количество отработанных дней работником</param>
        public PaymentRate(string name, string surname, int age, double salary, month currentMonth, int daysWorked, double rate)
        {
            Name = name;
            Surname = surname;
            Age = age;
            Salary = salary;
            CurrentMonth = currentMonth;
            DaysWorked = daysWorked;
            Rate = rate;
        }

        /// <summary>
        /// Аксессор получения имени
        /// </summary>
        public string Name
        {
            get
            { return _name; }
            set
            {
                _name = SetChecking(value);
            }
        }

        /// <summary>
        /// Аксессор получения фамилии
        /// </summary>
        public string Surname
        {
            get
            { return _surname; }

            set { _surname = SetChecking(value); }
        }

        /// <summary>
        /// Аксессор получения возраста
        /// </summary>
        public int Age
        {
            get { return _age; }
            set
            {
                if (value >= 150 || value < 14)
                    throw new ArgumentException("Неверно введет возраст, не менее 14, не более 150");
                _age = value;
            }
        }

        /// <summary>
        /// Аксессор для получения информации о типе начисления ЗП
        /// </summary>
        public PaymentType PaymentType
        {
            get { return _paymentType; }
        }

        /// <summary>
        /// Аксессор получения оклада. Минимум 10000руб
        /// </summary>
        public double Salary
        {
            get { return _salary; }
            set
            {
                if (value < 10000)
                {
                    throw new ArgumentException("Неверно введен размер оклада, не меньше 10000 рублей");
                }
                _salary = value;
            }
        }

        /// <summary>
        /// Аксессор получения количества рабочих дней в месяце
        /// Минимум 17(в январе) максимум 23(в августе)
        /// </summary>
        public month CurrentMonth
        {
            get
            {
                return _currentMonth;
            }
            set
            {
                _currentMonth = value;
            }

        }

        /// <summary>
        /// Аксессор получения количества отработанных дней работником.
        /// </summary>
        public int DaysWorked
        {
            get { return _daysWorked; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Неверно введено количество отработанных дней");
                }
                _daysWorked = value;
            }
        }

        /// <summary>
        /// Аксессор для получения ставки
        /// </summary>
        public double Rate
        {
            get
            {
                return _rate;
            }
            set
            {
                if (value < 0 || value > 1)
                {
                    throw new ArgumentException("Неверно введена ставка");
                }
                _rate = value;
            }
        }

        /// <summary>
        /// Расчет ЗП с учетом НДФЛ(13%) и вычетов. 
        /// 400руб - стандартный вычет для резидентов РФ.
        /// </summary>
        /// <returns>ЗП в рублях расчитанная по формуле с учетом НДФЛ, вычетов и ставки</returns>
        public double SalariesEnrollment()
        {
            return (((_salary) - ((_salary - 400) * IncomeTax) / 100) * _daysWorked * _rate) /
                (WorkingCalendare.WorkingDaysInMonth[DateTime.Now.Month]);
        }
    }

}