﻿namespace Billing
{
    public enum PaymentType
    {
        HourlyPay,
        PaymentOfSalary,
        PaymentRate
    }
}