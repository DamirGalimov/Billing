﻿namespace Billing
{
    public enum month
    {
        January = 17,
        Ferruary = 18,
        Marth = 22,
        April = 20,
        May = 20,
        June = 21,
        July = 21,
        August = 23,
        September = 21,
        October = 22,
        November = 21,
        December = 21
    }
}